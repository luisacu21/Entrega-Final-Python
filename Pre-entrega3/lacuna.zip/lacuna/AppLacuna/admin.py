from django.contrib import admin
from AppLacuna.models import *

# Register your models here.

admin.site.register(Pokemon)
admin.site.register(Entrenador)
admin.site.register(Gym)

