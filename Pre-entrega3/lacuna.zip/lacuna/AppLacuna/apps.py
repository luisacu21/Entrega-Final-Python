from django.apps import AppConfig


class ApplacunaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppLacuna'
